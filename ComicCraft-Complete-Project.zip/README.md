# ComicCraft — AI Comic Story Creator

A full-stack Generative AI application that turns a user's idea into a multi-panel comic story and generated comic-panel images using Google Gemini models.

## Stack

- Frontend: React + Vite
- Backend: Node.js + Express
- AI: Google Gemini via `@google/genai`
- Styling: Plain CSS (responsive, no UI framework)
- Persistence: Browser localStorage for recent projects

## Main flow

1. User enters a title, genre, characters, setting, plot, art style, and panel count.
2. React sends the request to `POST /api/comic/generate`.
3. Express asks Gemini to create structured comic-panel descriptions.
4. Express generates an image for each panel with Gemini image generation.
5. The API returns the story plus base64 images.
6. React renders the comic and lets the user download individual panels or the complete story as JSON.

## Requirements

- Node.js 20+
- npm 10+
- A Gemini API key from Google AI Studio

## Quick start

### 1. Backend

```bash
cd backend
npm install
copy .env.example .env
```

On macOS/Linux:

```bash
cp .env.example .env
```

Edit `.env`:

```env
GEMINI_API_KEY=your_key_here
PORT=5000
```

Start:

```bash
npm run dev
```

### 2. Frontend

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite, normally `http://localhost:5173`.

The frontend uses `/api` and Vite proxies that path to `http://localhost:5000`.

## Production build

```bash
cd frontend
npm run build
npm run preview
```

For a production deployment, deploy the frontend and backend separately or configure Express to serve the frontend `dist` folder.

## API

### GET `/api/health`

Returns service status.

### POST `/api/comic/generate`

Example body:

```json
{
  "title": "The Last Signal",
  "genre": "Sci-Fi",
  "characters": "Maya, a brave college student; Echo, a small AI robot",
  "setting": "A flooded Chennai in the near future",
  "plot": "Maya follows a mysterious radio signal that may save her neighborhood.",
  "style": "Cinematic graphic novel",
  "panelCount": 4
}
```

## Notes

Image generation consumes Gemini API quota. A 4-panel request can make multiple AI calls. Start with 3–4 panels while testing.

The app keeps the Gemini key only on the backend. Never put the key in `frontend/.env` or client-side JavaScript.

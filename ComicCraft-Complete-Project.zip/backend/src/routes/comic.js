import { Router } from "express";
import { generateComic } from "../services/gemini.js";

const router = Router();

function validate(body) {
  const required = ["title", "genre", "characters", "setting", "plot", "style"];
  const missing = required.filter((key) => !String(body?.[key] || "").trim());

  if (missing.length) {
    return `Missing fields: ${missing.join(", ")}`;
  }

  const panelCount = Number(body.panelCount);
  if (!Number.isInteger(panelCount) || panelCount < 1 || panelCount > 8) {
    return "panelCount must be an integer from 1 to 8.";
  }

  return null;
}

router.post("/generate", async (req, res) => {
  const validationError = validate(req.body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  try {
    const comic = await generateComic(req.body);
    return res.json(comic);
  } catch (error) {
    console.error("Comic generation error:", error);
    return res.status(500).json({
      error: error?.message || "Unable to generate comic."
    });
  }
});

export default router;
